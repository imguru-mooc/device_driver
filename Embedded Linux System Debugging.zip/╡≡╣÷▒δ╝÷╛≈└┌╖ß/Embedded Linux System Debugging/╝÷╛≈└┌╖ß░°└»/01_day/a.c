#include <stdio.h>

typedef struct
{
	signed char ch:1;
} BIT;
int main()
{
	BIT bit;
	bit.ch = 1;
	// 1 
	printf("ch=%d\n", bit.ch);
	return 0;
}
