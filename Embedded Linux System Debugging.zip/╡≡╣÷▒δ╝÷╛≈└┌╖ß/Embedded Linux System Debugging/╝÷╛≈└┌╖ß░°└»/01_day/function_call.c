#if 1
int foo(int a1, int a2)
{
	int result;
	result = a1+a2;
	return result;
}

int main()
{
	int result;
	result = foo(10, 20);
	return 0;
}

#endif

#if 0
void foo(void)
{
}

int main()
{
	foo();
	return 0;
}
#endif
