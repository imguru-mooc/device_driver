#include <stdio.h>

typedef struct layout
{
    struct layout* fp;
    void* ip;
    void* lr;
} layout;

void foo()
{
    layout* fp = __builtin_frame_address(0);
	fp = (void*)fp-12;
	printf("0x%08x\n", (unsigned int)fp->lr );
}

int main()
{
	foo();
	return 0;
}
