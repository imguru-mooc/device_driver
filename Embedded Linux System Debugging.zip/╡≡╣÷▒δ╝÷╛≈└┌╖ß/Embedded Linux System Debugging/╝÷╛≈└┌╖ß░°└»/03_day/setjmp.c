#if 1
#include <stdio.h>
#include <setjmp.h>
// typedef int jmp_buf[16];
jmp_buf env;  // int env[16];

void bar()
{
	printf("정상동작\n");
	longjmp(env, 2);  // throw 2
}
void foo()
{
	printf("정상동작\n");
	bar();
}

int main()
{
	int ret;
	if( (ret = setjmp(env) ) == 0)  // try
	{
		foo();
	}	
	else if( ret == 1 )  // catch 1
	{
		printf("error 1\n");
	}
	else if( ret == 2 )  // catch 2
	{
		printf("error 2\n");
	}
	return 0;
}
#endif
#if 0
#include <stdio.h>
int flag = 0;
void foo()
{
	flag = -1;
	if( flag < 0 )
		goto err;
}


int main()
{
	while(1)
	{
		while(1)
		{
			foo();
		}
	}
	return 0;
err:
	printf("error\n");
	return -1;
}
#endif

