#include <stdio.h>

void foo()
{
}

int main()
{ 
	int local;
	printf("hello : &local=%p\n", &local);
	foo();
	return 0;
}
