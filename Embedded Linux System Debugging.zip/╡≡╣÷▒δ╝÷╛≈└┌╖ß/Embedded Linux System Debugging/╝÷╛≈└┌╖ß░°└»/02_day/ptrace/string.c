#if 1
#include <stdio.h>
int main()
{
	int i;
	for(i=0;  i["hello"] ; i++ )
		putchar( i["hello"]);
	putchar('\n');

		return 0;
}
#endif
#if 0
#include <stdio.h>
int main()
{
	int i;
	for(i=0;  "hello"[i] ; i++ )
		putchar("hello"[i]);
	putchar('\n');

		return 0;
}
#endif
#if 0
#include <stdio.h>
int main()
{
	char *p = "hello";
	printf("sizeof(p)=%lu\n", sizeof(p));
	printf("sizeof(\"hello\")=%lu\n", sizeof("hello"));
	printf("p=%s\n", p);
	printf("p=%s\n", "hello");
	return 0;
}
#endif
