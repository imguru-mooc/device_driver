void **getFP(int dummy)
{
	void **fp = (void**)&dummy + 6 ;
	return fp;
}

int main()
{ 
	getFP(10);
	return 0;
}

