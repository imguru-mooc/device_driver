#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
int main()
{
	int fd;
	int i=0;
	char *p;
	p = malloc(1024);
	fd = open("/tmp/foo",  O_RDONLY );
	if ( fd < 0 )
	{
		//printf("open : error , errstr=%s\n", strerror(errno) );
		perror( "open" ); 
		exit(-1);
	}
	else 
		i=2;
	return i;
}

