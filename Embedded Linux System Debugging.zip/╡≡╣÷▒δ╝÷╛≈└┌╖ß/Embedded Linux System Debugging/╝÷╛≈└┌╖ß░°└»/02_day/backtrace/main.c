#include <execinfo.h>
#include <stdio.h>
#include <stdlib.h>

void print_gnu_backtrace();

void bar()
{
    print_gnu_backtrace();
}

void foo()
{
    bar();
}

int main()
{
    foo();
    return 0;
}

