#include <stdio.h>

int main(int argc, char **argv)
{
	printf("no. of argc = %d\n", argc);

	return argc;  // exit(argc);
}

