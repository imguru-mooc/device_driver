#include <stdio.h>
	
int main(int argc, char **argv)
{
	int i = 0;
	int j = 0;

	i=3;
	j=4;
	i=i*j+2;
	printf("Hello, world! %d, %d\n", i, j);

	return i;
}

