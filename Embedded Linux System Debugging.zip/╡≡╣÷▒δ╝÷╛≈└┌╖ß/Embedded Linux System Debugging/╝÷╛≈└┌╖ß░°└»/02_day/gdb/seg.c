#include <stdio.h>
#include <string.h>

char *gPtr;  // bss 영역에 할당

int main(int argc, char **argv)
{

	strcpy(gPtr, "abcd");  // *dst++ = *src++			
	printf("%s\n", gPtr);

	return 0;
}

