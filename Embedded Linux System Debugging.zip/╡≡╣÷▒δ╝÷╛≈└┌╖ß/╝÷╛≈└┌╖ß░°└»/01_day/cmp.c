#if 1
#include <stdio.h>

typedef struct
{
	signed char ch : 1;
} BIT;

int main()
{
	BIT bit = {1};
	// 1 => -1

	printf("%d\n", bit.ch );

	return 0;
}
#endif
#if 0
#include <stdio.h>

typedef struct
{
	signed char ch : 2;
} BIT;

int main()
{
	BIT bit = {2};
	// 10 => -2

	if( bit.ch == 2 )
	 	printf("%d\n", bit.ch );

	return 0;
}
#endif
#if 0
#include <stdio.h>
int main()
{
	signed short ch = 0xfffe; // 11111111 11111110
	                          // 00000000 00000010 => -2
	printf("%d\n", ch );

	return 0;
}
#endif
#if 0
#include <stdio.h>
int main()
{
	signed char ch = 250; // 11111010
	                      // 00000110 => -6
	printf("%d\n", ch );

	return 0;
}
#endif
