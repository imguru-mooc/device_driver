#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdio.h>
void foo()
{
	Dl_info info;
	void *p = foo+100;
	printf( "%p\n", p );
	dladdr( p, &info );
	printf("%s\n", info.dli_sname);
	printf("%s\n", info.dli_fname);
}

int main()
{
	foo();
	return 0;
}
