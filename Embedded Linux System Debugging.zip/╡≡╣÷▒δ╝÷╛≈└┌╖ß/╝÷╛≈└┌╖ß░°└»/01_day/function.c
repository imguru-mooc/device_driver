#if 1
#include <stdio.h>
#include <stdarg.h>
int vsum( int num, ... );
int main()
{
	int ret;
	ret = vsum( 4, 10, 20, 30, 40 );
	printf("%d\n", ret );
	return 0;
}
int vsum( int num, ... )
{
	int result=0; 
	int i;
	va_list va;
	va_start( va, num );
	printf("vsum, num=%d\n", num );
	for(i=0; i<num; i++ )
		result += va_arg( va, int );
	return result;
}
#endif
#if 0
#include <stdio.h>
#include <stdarg.h>
int vsum( int num, ... );
int main()
{
	int ret;
	ret = vsum( 2, 10, 20 );
	printf("%d\n", ret );
	ret = vsum( 3, 10, 20, 30 );
	printf("%d\n", ret );
	return 0;
}
int vsum( int num, ... )
{
	int result=0; 
	int i;
	va_list va;
	va_start( va, num );
	printf("vsum, num=%d\n", num );
	for(i=0; i<num; i++ )
		result += va_arg( va, int );
	return result;
}
#endif

#if 0

int printf( const char *, ... );
int main()
{
	printf( "hello world %d %d\n", 1, 2);
	return 0;
}
#endif
#if 0

void bar()
{
}

void foo(int a1, int a2, int a3, int a4, int a5)
{
	bar();
}

int main()
{
	foo(1,2,3,4,5);
	return 0;
}
#endif
#if 0

void bar()
{
}

int foo(int a1, int a2)
{
	bar();
	return a1+a2;
}

int main()
{
	foo(10,20);
	return 0;
}
#endif
#if 0

int foo(int a1, int a2)
{
	return a1+a2;
}

int main()
{
	foo(10,20);
	return 0;
}
#endif
#if 0

int foo(int a1, int a2)
{
	return a1+a2;
}

int main()
{
	foo(10,20);
	return 0;
}
#endif
#if 0

int foo(void)
{
	return 10;
}

int main()
{
	foo();
	return 0;
}
#endif
#if 0

void foo(int a1, int a2)
{
}

int main()
{
	foo(10,20);
	return 0;
}
#endif

#if 0
void hoo(void)
{
}
void bar(void)
{
	hoo();
}

void foo(void)
{
	bar();
}

int main()
{
	foo();
	return 0;
}
#endif

