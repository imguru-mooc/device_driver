#if 1
#include <stdio.h>
int main()
{
	signed char bitmap = -3;
	//  11111101
	//  11111110 => -2

	while(1)
	{
		printf("%d\n", bitmap );
		bitmap >>= 1;
		getchar();
	}

	return 0;
}
#endif
#if 0
#include <stdio.h>
int main()
{
	unsigned char bitmap = 32;

	while(1)
	{
		printf("%d\n", bitmap );
		bitmap >>= 1;
		getchar();
	}

	return 0;
}
#endif
#if 0
#include <stdio.h>
int main()
{
	int bitmap = -32;

	while(1)
	{
		printf("%d\n", bitmap );
		bitmap >>= 1;
		getchar();
	}

	return 0;
}
#endif
#if 0
#include <stdio.h>
int main()
{
	int flag = 7;
	int key  = flag ^ 8;

	while(1)
	{
		printf("%d\n", flag );
		flag ^= key;
		getchar();
	}

	return 0;
}
#endif
#if 0
#include <stdio.h>
int main()
{
	int flag = 5;

	while(1)
	{
		printf("%d\n", flag );
		if( flag == 5 )
			flag = 6;
		else if ( flag == 6 )
			flag = 5;
		getchar();
	}

	return 0;
}
#endif
#if 0
#include <stdio.h>
int main()
{
	int bitmap = 0;
	// 0000
	int i;

	bitmap |= 1;
	bitmap |= 8;

	for( i=0 ; i<32; i++ )
		if( bitmap & (1<<i) )
			printf("%d\n", i );

	bitmap &= ~8;
	printf("----------\n");
	for( i=0 ; i<32; i++ )
		if( bitmap & (1<<i) )
			printf("%d\n", i );
	return 0;
}
#endif
#if 0
#include <stdio.h>
int main()
{
	int bitmap = 0;
	// 0000
	int i;

	bitmap |= 1<<0;
	bitmap |= 1<<3;

	for( i=0 ; i<32; i++ )
		if( bitmap & (1<<i) )
			printf("%d\n", i );
	return 0;
}
#endif
#if 0
#include <stdio.h>
int main()
{
	int bitmap = 0x12345678;
	// 000100100011010001010011001111000

	int i;

	for( i=0 ; i<32; i++ )
		if( bitmap & (1<<i) )
			printf("%d\n", i );
	return 0;
}
#endif
