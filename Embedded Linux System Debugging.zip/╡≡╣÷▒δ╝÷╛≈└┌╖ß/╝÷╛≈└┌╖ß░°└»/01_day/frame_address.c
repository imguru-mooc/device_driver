#if 1
#include <stdio.h>

void **getFP(int dummy)
{
	void **fp = (void**)&dummy + 6 ;
	return fp;
}

void bar()
{
	int dummy=10;
	void **fp = getFP(dummy);

	printf("bar : &fp=%p\n", &fp);
	printf("bar : fp=%p\n", fp);
}
void foo()
{
	int dummy=10;
	void **fp = getFP(dummy);

	printf("foo : &fp=%p\n", &fp);
	printf("foo : fp=%p\n", fp);
	bar();
}

int main()
{
	foo();
	return 0;
}
#endif
#if 0
#include <stdio.h>
void bar()
{
	void *fp = __builtin_frame_address(0);
	printf("bar : &fp=%p\n", &fp);
	printf("bar : fp=%p\n", fp);
}

void foo()
{
	void *fp = __builtin_frame_address(0);
	printf("foo : &fp=%p\n", &fp);
	printf("foo : fp=%p\n", fp);
	bar();
}

int main()
{
	foo();
	return 0;
}
#endif
