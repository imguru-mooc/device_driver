#include <stdio.h>
#include <stdlib.h>

typedef struct layout
{
	struct layout* fp;
	void* ip;
	void* lr;
} layout;

void print_gnu_backtrace()
{
	layout* fp = __builtin_frame_address(0);
	while( fp )
	{
		fp = (void*)fp-12;
		printf("0x%08x\n", (unsigned int)fp->lr );
		fp = fp->fp;
	}
}

void bar()
{
	print_gnu_backtrace();
}

void foo()
{
	bar();
}

int main()
{
	foo();
	return 0;
}

