#include <unistd.h>
#include <fcntl.h>
int main()
{
	char *argv[] = {"ls", 0 };
	int fd;

	fd = open("xxx", O_WRONLY|O_CREAT|O_TRUNC, 0666);
	dup2(fd, 1);

	execve("/bin/ls", argv, 0) ;
	return 0;
}
