
#if 1
#include <stdio.h>
int main()
{
	int i;
	for( i=0; "hello"[i]; i++ )
		putchar(i["hello"] );
	putchar('\n');
	return 0;
}
#endif

#if 0
#include <stdio.h>
int main()
{
	int i;
	for( i=0; "hello"[i]; i++ )
		printf("%c", i["hello"] );
	printf("\n");
	return 0;
}
#endif
#if 0
#include <stdio.h>
int main()
{
	printf("%c\n", 3["hello"] );
	printf("%c\n", *(3+"hello") );
	return 0;
}
#endif

#if 0
#include <stdio.h>
int main()
{
	char *p = "hello";

	printf("%c\n", 3[p] );
	printf("%c\n", *(3+p) );
	return 0;
}
#endif
#if 0
#include <stdio.h>
int main()
{
	char *p = "hello";
	// char [6]  
	// array of 6
	// char

	printf("%c\n", p[3] );
	printf("%c\n", *(p+3) );
	return 0;
}
#endif
#if 0
#include <stdio.h>
int main()
{
	char a[6] = "hello";
	// char [6]  
	// array of 6
	// char
	*(a+3) = 'a';

	printf("%s\n", a );
	printf("sizeof(a)=%u\n", sizeof(a) );
	printf("sizeof(char[6])=%u\n", sizeof(char[6]) );
	return 0;
}
#endif
#if 0
#include <stdio.h>
int main()
{
	char a[6] = "hello";
	a[0] = 'a';
	//a = "world";
	printf("%s\n", a );
	printf("sizeof(a)=%u\n", sizeof(a) );
	printf("sizeof(char[6])=%u\n", sizeof(char[6]) );
	return 0;
}
#endif

#if 0
#include <stdio.h>
int main()
{
	char *p = "hello";
	printf("%s\n", p );
	p = "world";
	printf("%s\n", p );
	return 0;
}
#endif
#if 0
#include <stdio.h>
int main()
{
	// char __aaa[6] = "hello";
	char *p = "hello";
	// *p = 'a';
	printf("%s\n", p );
	printf("sizeof(p)=%u\n", sizeof(p) );
	printf("sizeof(\"hello\")=%u\n", sizeof("hello") );
	printf("sizeof(char[6])=%u\n", sizeof(char[6]) );
	return 0;
}
#endif
