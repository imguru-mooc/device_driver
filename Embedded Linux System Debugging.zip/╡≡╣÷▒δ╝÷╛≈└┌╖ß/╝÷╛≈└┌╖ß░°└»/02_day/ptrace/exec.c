#include <sys/ptrace.h>
#include <sys/user.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <asm/ptrace.h>

int main(int argc, char *argv[])
{
	int pid, status, ret;
	struct user_regs regs;

	if(!(pid = fork())) {
		//execl( "/bin/ls" , "/bin/ls" , NULL );
		int i;
		for(i=0; ; i++)
		{
			printf("child\n");
			sleep(1);
		}
		exit(7);
	}
	waitpid(-1,&status,WUNTRACED);
	printf("%x\n", status );
	if( WIFEXITED(status) )
		printf("exit(%d)\n", WEXITSTATUS(status));

	if( WIFSIGNALED(status) )
		printf("signo(%d)\n", WTERMSIG(status));

	if( WIFSTOPPED(status) )
		printf("stopped(%d)\n", WSTOPSIG(status));

	return 0;
}

