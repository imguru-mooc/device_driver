#if 1
#include <sys/ptrace.h>
#include <sys/user.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <asm/ptrace.h>

int main(int argc, char *argv[])
{
	int pid, status, ret;
	struct user_regs regs;

	if(!(pid = fork())) {
		ptrace(PTRACE_TRACEME, 0, 0, 0);
		execl( "/bin/ls" , "/bin/ls" , NULL );
		return 0;
	}

	while(1)
	{
		wait(&status);
		//printf("%x\n", status );
		if(WIFSIGNALED(status)) {
			fprintf(stderr, "child process %d was abnormal exit.\n", pid);
			return -1;
		}
		if(WIFEXITED(status)) {
			fprintf(stderr, "child process %d was normal exit.\n", pid);
			return -1;
		}

		ret = ptrace(PTRACE_GETREGS, pid, 0, &regs);

//		printf( "%d, %d\n", regs.ARM_r7 , regs.ARM_ip);
		if( regs.ARM_r7 == 5 )
		{
			if( regs.ARM_ip == 0 )
			{
				int i;
				char buff[256];
				int data;
				for(i=0; i<10; i++)
				{
					data = ptrace(PTRACE_PEEKDATA, pid, regs.ARM_r0+i*4, 0);
					memcpy( buff+i*4, &data, 4 );
				}
				printf("open(\"%s\")" , buff );
			}
			else if ( regs.ARM_ip == 1 )
			{
				printf(" = %d\n" , regs.ARM_r0 );
			}
		}

		ptrace(PTRACE_SYSCALL, pid, 0, 0);
//		getchar();
	}
}
#endif

#if 0
#include <sys/ptrace.h>
#include <sys/user.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <asm/ptrace.h>

int main(int argc, char *argv[])
{
	int pid, status, ret;
	struct user_regs regs;

	if(!(pid = fork())) {
		ptrace(PTRACE_TRACEME, 0, 0, 0);
		execl( "/bin/ls" , "/bin/ls" , NULL );
		return 0;
	}
	wait(&status);
	printf("%x\n", status );
	if(WIFSIGNALED(status)) {
		fprintf(stderr, "child process %d was abnormal exit.\n", pid);
		return -1;
	}

	ret = ptrace(PTRACE_GETREGS, pid, 0, &regs);
	printf("stack sp = %p\n", (void*)regs.ARM_sp);
	printf("pc       = %p\n", (void*)regs.ARM_pc);

	ptrace(PTRACE_DETACH, pid, 0, 0);
	//ptrace(PTRACE_KILL, pid, 0, 0);
}
#endif

