#include <stdio.h>
#include <unistd.h>
int main()
{
	int i;
	char str[] = "hello";
	for( i=0; ; i++)
	{
		printf("%s! %d\n", str, i);
		sleep(1);
	} 
	return 0;
}

