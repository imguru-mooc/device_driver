#if 1
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/wait.h>
void handler(void)
{
	char ip[] = "192.168.56.100";
	char *p;

	p = strtok( ip, "." );
	while( p )
	{
		printf("[%s]\n", p );
		p = strtok( 0, "." );
		sleep(20);
	}
}

int main()
{
	if(fork()==0)
	{
		handler();
		exit(0);
	}

	while(1)
	{
		printf("parent\n");
		sleep(1);
	}
	return 0;
}
#endif

#if 0
#include <stdio.h>
#include <string.h>
int main()
{
	char ip[] = "192.168.56.100";
	char *p;

	p = strtok( ip, "." );
	while( p )
	{
		printf("[%s]\n", p );
		p = strtok( 0, "." );
	}
	return 0;
}
#endif
