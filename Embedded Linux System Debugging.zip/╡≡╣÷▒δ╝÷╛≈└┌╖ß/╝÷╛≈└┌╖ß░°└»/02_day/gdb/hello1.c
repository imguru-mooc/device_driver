#include <stdio.h>

// 3. int main(void)
// 4. int main(int, char **)
// 5. int main(int, char **, char **)

// # ./a.out   a      b
//   argv[0] argv[1] argv[2]
//   argc=3

int main(int argc, char **argv)
{
	int i;
	printf("no. of args = %d\n", argc);
	for(i=0; i<argc; i++ )
	printf("argv[%d]=[%s]\n", i, argv[i]);

	return argc;
}

