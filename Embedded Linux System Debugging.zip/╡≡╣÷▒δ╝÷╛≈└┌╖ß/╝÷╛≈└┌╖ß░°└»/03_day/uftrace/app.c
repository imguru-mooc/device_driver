#include <stdio.h>
#include "app.h"

int main()
{
	int ret;
	ret = add(1,2);
	printf("ret = %d\n", ret );
	return 0;
}


