#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/gpio.h>

int my_init(void)
{
	int value;
	printk("my_init()\n");
	value = gpio_get_value(190);
	return 0;
}

void my_exit(void)
{
	printk("my_exit()\n");
}

module_init(my_init);
module_exit(my_exit);
MODULE_LICENSE("GPL");


