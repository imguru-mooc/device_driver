#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/gpio.h>
#include <linux/moduleparam.h>

static int gpio=190;
module_param( gpio, int, 0644);		

int my_init(void)
{
	int value;
	printk("my_init() , gpio=%d\n" , gpio);
	value = gpio_get_value(gpio);
	return 0;
}

void my_exit(void)
{
	printk("my_exit()\n");
}

module_init(my_init);
module_exit(my_exit);
MODULE_LICENSE("GPL");


