#if 1
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <setjmp.h>

sigjmp_buf env;
void my_handler(int data)
{
	printf("my_handler(%d)\n", data );
	siglongjmp( env, 1 );
}

int main()
{
	char buff[1024];
	int ret;
	int i;
	int savesigs;
	signal( SIGALRM, my_handler );
	for(i=0; i<3; i++)
	{
		alarm(5);
		if( sigsetjmp(env, savesigs) == 0 )
		{
			ret = read(0, buff, sizeof buff);
			buff[ret-1] = 0;
			printf("%d번째 : %s\n", i, buff );
		}
		alarm(0);
	}
	return 0;
}
#endif

#if 0
#include <stdio.h>
#include <setjmp.h>

//int env[16]  ;
//typedef int jmp_buf[16];

jmp_buf env;

void foo(void)
{
	int flag=10;
	flag = -1;
	while(1)
	{
		if( flag < 0 )
		{
			longjmp( env, 1 );
		}
	}
}

int main()
{
	int ret;

	if(0==(ret=setjmp(env)))
	{
		foo();
	}
	else if( ret == 1 )
	{
		printf("error %d\n", ret );
	}
	return 0;
}
#endif
#if 0
#include <stdio.h>
void foo(void)
{
	int flag=10;
	flag = -1;
	while(1)
	{
		if( flag < 0 )
		{
			throw 1;
		}
	}
}

int main()
{
	try 
	{
		foo();
	}
	catch(e)
	{
		printf("error\n");
	}
	return 0;
}
#endif
#if 0
#include <stdio.h>
void foo(void)
{
	int flag=10;
	flag = -1;
	if( flag < 0 )
	{
		goto err;
	}
}

int main()
{
	while(1)
	{
		while(1)
		{
			foo();
		}
	}
	return 0;
err:
	printf("error\n");
	return -1;
}
#endif
#if 0
#include <stdio.h>
int main()
{
	int flag=10;
	flag = -1;

	while(1)
	{
		while(1)
		{
			if( flag < 0 )
			{
				goto err;
			}
		}
	}
	return 0;
err:
	printf("error\n");
	return -1;
}
#endif
#if 0
#include <stdio.h>
int main()
{
	int flag=10;
	flag = -1;

	while(1)
	{
		while(1)
		{
			if( flag < 0 )
			{
				break;
			}
		}
		if( flag < 0 )
		{
			break;
		}
	}
	if( flag < 0 )
	{
		printf("error\n");
	}
	return 0;
}
#endif
#if 0
int main()
{
	int flag=10;
	flag = -1;

	while(1)
	{
		if( flag < 0 )
		{
			printf("error\n");
			break;
		}
	}
	return 0;
}
#endif

#if 0
int main()
{
	int flag=10;
	flag = -1;

	if( flag < 0 )
	{
		printf("error\n");
		exit(-1);
	}
	return 0;
}
#endif
