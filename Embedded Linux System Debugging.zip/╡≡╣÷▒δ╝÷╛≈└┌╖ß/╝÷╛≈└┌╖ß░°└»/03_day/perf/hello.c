void bar()
{
	int i;
	for( i=0; i<200000000; i++ )
		;
}
void foo()
{
	int i;
	for( i=0; i<100000000; i++ )
		;
	bar();
}
int main()
{
	foo();
	return 0;
}
